/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import javax.swing.JOptionPane;

/**
 *
 * @author cesar
 */
public class DaoNewGame {
    public boolean daoNewGameFoul()
    {
        JOptionPane.showMessageDialog(null, " Comunicacion logica al DAO para ingresar foul al repositorio");
        return true;
    }
    public boolean daoNewGamePoint()
    {
        JOptionPane.showMessageDialog(null, " Comunicacion logica al DAO para ingresar point al repositorio");
        return true;
    }
    public boolean daoNewGameAssit()
    {
        JOptionPane.showMessageDialog(null, " Comunicacion logica al DAO para ingresar assit al repositorio");
        return true;
    }
    public boolean daoNewGameBlocks()
    {
        JOptionPane.showMessageDialog(null, " Comunicacion logica al DAO para ingresar blocks al repositorio");
        return true;
    }
    public boolean daoNewGameQTR()
    {
        JOptionPane.showMessageDialog(null, " Comunicacion logica al DAO para ingresar qtr al repositorio");
        return true;
    }
}
