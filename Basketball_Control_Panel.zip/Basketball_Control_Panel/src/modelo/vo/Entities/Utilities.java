
package modelo.vo.Entities;

/**
 *
 * @author IceCreamSandwich
 */
public interface Utilities {
    
}
