package modelo.vo.Entities;

/**
 *
 * @author IceCreamSandwich
 */
public interface PrintInfo {
    //Prints class-specific data
    void printData();
    //Prints general statistics of a given class
    void printStats();
}

