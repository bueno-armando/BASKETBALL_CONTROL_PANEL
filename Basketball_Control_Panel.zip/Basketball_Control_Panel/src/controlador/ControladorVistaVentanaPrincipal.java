/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import vista.*;
/**
 *
 * @author cesar
 */
public class ControladorVistaVentanaPrincipal {
    public static VentanaPrincipal vPrincipal = new VentanaPrincipal();
    public static VentanaNewGame vNewGame = new VentanaNewGame();
    public static VentanaStatsPrincipal vStats = new VentanaStatsPrincipal(vPrincipal, true);
    public static VentanaPosiciones vPosiciones = new VentanaPosiciones(vPrincipal, true);
    public static VentanaEditTeam vEditTeams = new VentanaEditTeam(vPrincipal, true);
    
    //Mostrar ventana principal
    public static void mostrarVentanaPrincipal()
    {
        vPrincipal.setVisible(true);
    }
    //Mostrar ventana New Game
    public static void mostrarVentanaNewGame()
    {
        vNewGame.setVisible(true);
    }
    
    //Mostrar ventana Stats
    public static void mostrarVentanaStats(){
        vStats.setVisible(true);
    }
    
    //Mostrar ventana LoadTeams
    public static void mostrarVentanaEditTeam(){
        vEditTeams.setVisible(true);
    }
    
    //Mostrar ventana Leaderboard
    public static void mostrarVentanaPosiciones(){
        vPosiciones.setVisible(true);
    }
    
    //Enventos VentanaPrincipal
    public static void btn_Salir(){
        System.exit(0);
    }
}
